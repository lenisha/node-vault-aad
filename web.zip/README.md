
```

  CREATE TABLE [dbo].[assessment] (
    [assessment_id] [nvarchar](max),        
    [assessment_status] [nvarchar](max),
    [created_on] DATETIME,
    [modified_on] DATETIME
)
 GO

 Insert into [dbo].[assessment] ( assessment_id, assessment_status) values ('1000', 'success');
 Insert into [dbo].[assessment] ( assessment_id, assessment_status) values ('1002', 'retry');

 select * from [dbo].[assessment];
 ```

 https://docs.microsoft.com/en-us/sql/connect/node-js/step-3-proof-of-concept-connecting-to-sql-using-node-js?view=sql-server-2017

 https://docs.microsoft.com/en-us/azure/app-service/app-service-web-tutorial-connect-msi

 authentication: {
    type: 'azure-active-directory-password',
    options: {
      userName: 'test@lioranerosgmail.onmicrosoft.com',
      password: 'Papa7071',
    }
  },